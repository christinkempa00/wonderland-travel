<?php
/**
 * ================================================================
 * PATCH: Tambahkan routes berikut ke config/routes.php
 * ================================================================
 * 
 * Tambahkan di bagian routes:
 */

// ============================================
// ATTACHMENT STAFF ROUTES
// ============================================

'GET /attachment-dashboard' => ['AttachmentController', 'dashboard', 'auth'],
'GET /attachment-order/{id:\d+}' => ['AttachmentController', 'viewOrder', 'auth'],

// ============================================
// ATAU JIKA MENGGUNAKAN FORMAT ARRAY PENUH:
// ============================================

$routes = [
    // ... existing routes ...
    
    // ============================================
    // ATTACHMENT STAFF ROUTES
    // ============================================
    
    'GET /attachment-dashboard' => ['AttachmentController', 'dashboard', 'auth'],
    'GET /attachment-order/{id:\d+}' => ['AttachmentController', 'viewOrder', 'auth'],
];
