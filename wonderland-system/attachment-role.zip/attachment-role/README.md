# Role Staff Lampiran (Attachment)

Role khusus untuk staff yang **hanya bisa menginput data lampiran** tanpa akses ke fitur lainnya.

## 🎯 Fitur Role Attachment

| Fitur | Akses |
|-------|-------|
| Dashboard Khusus | ✅ Melihat daftar pesanan yang perlu diinput lampiran |
| Input Data Hotel | ✅ Bisa input tamu hotel dan upload logo |
| Input Data Pesawat | ✅ Bisa input data penumpang |
| Input Data Kendaraan | ✅ Bisa input data bus/towing |
| Input Data Rental | ✅ Bisa input data rental mobil |
| Cetak Lampiran | ✅ Bisa cetak semua jenis lampiran |
| Lihat Harga | ❌ **Tidak bisa** |
| Buat/Edit Pesanan | ❌ **Tidak bisa** |
| Keuangan/Akuntansi | ❌ **Tidak bisa** |
| Klien | ❌ **Tidak bisa** |
| Pengaturan | ❌ **Tidak bisa** |

---

## 📦 Struktur File

```
attachment-role/
├── add_role_attachment.sql          # SQL untuk menambah role
├── patch_constants.php              # Update config/constants.php
├── patch_routes.php                 # Routes baru
├── patch_app_layout.php             # Modifikasi layout
├── patch_dashboard_controller.php   # Redirect setelah login
├── controllers/
│   └── AttachmentController.php     # Controller baru
└── views/
    ├── layouts/
    │   └── sidebar-attachment.php   # Sidebar khusus
    └── attachments/
        ├── dashboard.php            # Dashboard lampiran
        └── order-detail.php         # Detail order (tanpa harga)
```

---

## 🚀 Cara Install

### 1. Jalankan SQL

```sql
-- Di phpMyAdmin, jalankan:

-- Tambah role baru ke enum
ALTER TABLE `users` 
MODIFY COLUMN `role` ENUM('superadmin','admin','staff','accounting','viewer','attachment') DEFAULT 'staff';

-- (Optional) Buat user testing
INSERT INTO `users` (`name`, `email`, `password`, `phone`, `role`, `is_active`, `created_at`) VALUES
('Staff Lampiran', 'lampiran@pelitaintimulia.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', NULL, 'attachment', 1, NOW());

-- Password: lampiran123
```

### 2. Update config/constants.php

Tambahkan setelah `define('ROLE_VIEWER', 'viewer');`:

```php
define('ROLE_ATTACHMENT', 'attachment');
```

Update array `ROLES`:

```php
define('ROLES', [
    ROLE_SUPERADMIN => 'Super Admin',
    ROLE_ADMIN => 'Administrator',
    ROLE_STAFF => 'Staff',
    ROLE_ACCOUNTING => 'Akuntansi',
    ROLE_VIEWER => 'Viewer',
    ROLE_ATTACHMENT => 'Staff Lampiran'  // TAMBAH INI
]);
```

Update array `PERMISSIONS`:

```php
define('PERMISSIONS', [
    // ... existing roles ...
    
    // TAMBAH INI:
    ROLE_ATTACHMENT => [
        'dashboard.view',
        'attachments.*',
        'orders.view_limited'
    ]
]);
```

### 3. Copy Files

```bash
# Controller
cp controllers/AttachmentController.php /path/to/travel/controllers/

# Views
cp views/layouts/sidebar-attachment.php /path/to/travel/views/layouts/
mkdir -p /path/to/travel/views/attachments/
cp views/attachments/dashboard.php /path/to/travel/views/attachments/
cp views/attachments/order-detail.php /path/to/travel/views/attachments/
```

### 4. Update config/routes.php

Tambahkan routes:

```php
// Attachment Staff Routes
'GET /attachment-dashboard' => ['AttachmentController', 'dashboard', 'auth'],
'GET /attachment-order/{id:\d+}' => ['AttachmentController', 'viewOrder', 'auth'],
```

### 5. Update views/layouts/app.php

Cari baris yang include sidebar, ganti dengan:

```php
// Pilih sidebar berdasarkan role
$userRole = Session::userRole();
if ($userRole === 'attachment') {
    include VIEWS_PATH . '/layouts/sidebar-attachment.php';
} else {
    include VIEWS_PATH . '/layouts/sidebar.php';
}
```

### 6. Update controllers/DashboardController.php

Tambahkan di awal method `index()`:

```php
public function index(): void {
    // Redirect attachment role ke dashboard khusus
    if (Session::userRole() === 'attachment') {
        redirect('/attachment-dashboard');
        return;
    }
    
    // ... kode existing ...
}
```

---

## 🧪 Testing

1. Login dengan akun attachment: `lampiran@pelitaintimulia.com` / `lampiran123`
2. Akan langsung masuk ke **Dashboard Lampiran**
3. Sidebar hanya menampilkan menu lampiran
4. Coba akses `/dashboard` → akan redirect ke `/attachment-dashboard`
5. Coba input data tamu hotel → harus bisa
6. Coba akses `/orders` langsung → seharusnya tidak bisa

---

## 📝 Membuat User Attachment Baru

Di halaman Users (untuk admin), pilih role "Staff Lampiran" saat membuat user baru.

Atau via SQL:

```sql
INSERT INTO `users` (`name`, `email`, `password`, `role`, `is_active`) VALUES
('Nama Staff', 'email@domain.com', '$2y$10$...hashed_password...', 'attachment', 1);

-- Jangan lupa assign ke company:
INSERT INTO `user_companies` (`user_id`, `company_id`, `is_active`) 
VALUES (LAST_INSERT_ID(), 1, 1);
```

---

## ⚠️ Catatan Penting

1. **Keamanan**: Role attachment tidak bisa melihat informasi harga, profit, atau keuangan
2. **Akses Terbatas**: Hanya bisa mengakses halaman input lampiran dan cetak
3. **Sidebar Terpisah**: Menggunakan sidebar khusus tanpa menu sensitif
4. **Redirect Otomatis**: Login langsung ke dashboard lampiran
