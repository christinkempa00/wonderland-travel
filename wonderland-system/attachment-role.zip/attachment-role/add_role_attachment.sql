-- =============================================
-- ADD ROLE "ATTACHMENT" - Staff Lampiran
-- =============================================
-- Jalankan di phpMyAdmin

-- 1. MODIFY ENUM untuk menambah role 'attachment'
ALTER TABLE `users` 
MODIFY COLUMN `role` ENUM('superadmin','admin','staff','accounting','viewer','attachment') DEFAULT 'staff';

-- 2. (Optional) Buat user contoh untuk testing
-- Password: lampiran123
INSERT INTO `users` (`name`, `email`, `password`, `phone`, `role`, `is_active`, `created_at`) VALUES
('Staff Lampiran', 'lampiran@pelitaintimulia.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', NULL, 'attachment', 1, NOW());

-- 3. Assign ke company (ganti company_id sesuai kebutuhan)
INSERT INTO `user_companies` (`user_id`, `company_id`, `is_active`, `created_at`) 
SELECT LAST_INSERT_ID(), 1, 1, NOW();
