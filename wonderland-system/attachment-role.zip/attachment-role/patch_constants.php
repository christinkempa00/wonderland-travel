<?php
/**
 * ================================================================
 * PATCH: Tambahkan code berikut ke config/constants.php
 * ================================================================
 * 
 * Cari bagian "User Roles" dan tambahkan:
 */

// ============================================
// TAMBAH SETELAH: define('ROLE_VIEWER', 'viewer');
// ============================================
define('ROLE_ATTACHMENT', 'attachment');

// ============================================
// UPDATE ARRAY ROLES (ganti yang lama):
// ============================================
define('ROLES', [
    ROLE_SUPERADMIN => 'Super Admin',
    ROLE_ADMIN => 'Administrator',
    ROLE_STAFF => 'Staff',
    ROLE_ACCOUNTING => 'Akuntansi',
    ROLE_VIEWER => 'Viewer',
    ROLE_ATTACHMENT => 'Staff Lampiran'  // NEW
]);

// ============================================
// UPDATE ARRAY PERMISSIONS (ganti yang lama):
// ============================================
define('PERMISSIONS', [
    ROLE_SUPERADMIN => ['*'], // All permissions
    ROLE_ADMIN => [
        'dashboard.view',
        'orders.*',
        'clients.*',
        'documents.*',
        'profit.*',
        'accounting.*',
        'settings.company',
        'settings.users',
        'settings.templates',
        'settings.profit_sharing',
        'reports.*'
    ],
    ROLE_STAFF => [
        'dashboard.view',
        'orders.view',
        'orders.create',
        'orders.edit',
        'clients.view',
        'clients.create',
        'clients.edit',
        'documents.view',
        'documents.create'
    ],
    ROLE_ACCOUNTING => [
        'dashboard.view',
        'orders.view',
        'accounting.*',
        'reports.*',
        'profit.view'
    ],
    ROLE_VIEWER => [
        'dashboard.view',
        'orders.view',
        'clients.view',
        'documents.view',
        'reports.view'
    ],
    // NEW: Staff Lampiran - hanya bisa input lampiran
    ROLE_ATTACHMENT => [
        'dashboard.view',           // Dashboard khusus
        'attachments.*',            // Semua operasi lampiran
        'orders.view_limited'       // Lihat order terbatas (tanpa harga)
    ]
]);
