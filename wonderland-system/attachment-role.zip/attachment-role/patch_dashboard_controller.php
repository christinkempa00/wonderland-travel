<?php
/**
 * ================================================================
 * PATCH: Modifikasi controllers/DashboardController.php
 * ================================================================
 * 
 * Tambahkan di awal method index():
 */

public function index(): void {
    // ============================================
    // TAMBAHKAN KODE INI DI AWAL METHOD:
    // ============================================
    
    // Redirect attachment role ke dashboard khusus
    if (Session::userRole() === 'attachment') {
        redirect('/attachment-dashboard');
        return;
    }
    
    // ... kode existing selanjutnya ...
}

// ============================================
// ATAU MODIFIKASI AuthController di method login
// setelah login berhasil:
// ============================================

// Di AuthController.php, setelah login success:
public function login(): void {
    // ... proses login ...
    
    if ($loginSuccess) {
        // Redirect berdasarkan role
        $role = Session::userRole();
        
        if ($role === 'attachment') {
            redirect('/attachment-dashboard');
        } else {
            $redirectTo = Session::get('redirect_after_login') ?? '/dashboard';
            Session::remove('redirect_after_login');
            redirect($redirectTo);
        }
        return;
    }
}
