<?php
/**
 * ================================================================
 * PATCH: Modifikasi views/layouts/app.php
 * ================================================================
 * 
 * Cari bagian yang include sidebar dan ganti dengan:
 */

// ============================================
// GANTI BARIS INI:
// ============================================
// include VIEWS_PATH . '/layouts/sidebar.php';

// ============================================
// DENGAN KODE INI:
// ============================================

// Pilih sidebar berdasarkan role
$userRole = Session::userRole();
if ($userRole === 'attachment') {
    include VIEWS_PATH . '/layouts/sidebar-attachment.php';
} else {
    include VIEWS_PATH . '/layouts/sidebar.php';
}

// ============================================
// ALTERNATIF: Jika menggunakan helper function
// ============================================

/**
 * Tambahkan function ini di helpers/functions.php:
 */
function getSidebarFile(): string {
    $role = Session::userRole();
    
    switch ($role) {
        case 'attachment':
            return 'sidebar-attachment.php';
        default:
            return 'sidebar.php';
    }
}

// Lalu di app.php:
// include VIEWS_PATH . '/layouts/' . getSidebarFile();
