<?php
/**
 * ================================================================
 * ATTACHMENT CONTROLLER
 * ================================================================
 * 
 * Controller khusus untuk role "attachment" (Staff Lampiran)
 * Menampilkan daftar order yang memerlukan input lampiran
 */

class AttachmentController {
    
    /**
     * Dashboard untuk Staff Lampiran
     * Menampilkan daftar order yang memiliki item hotel/flight/vehicle/rental
     */
    public function dashboard(): void {
        // Check if user is attachment role
        if (Session::userRole() !== 'attachment') {
            // Non-attachment users get redirected to normal dashboard
            redirect('/dashboard');
            return;
        }
        
        $companyId = Session::companyId();
        $filter = $_GET['filter'] ?? 'all';
        $search = trim($_GET['search'] ?? '');
        $page = (int) ($_GET['page'] ?? 1);
        $perPage = 20;
        
        // Build query based on filter
        $itemTypes = [];
        switch ($filter) {
            case 'hotel':
                $itemTypes = ['hotel'];
                $filterLabel = 'Hotel';
                break;
            case 'flight':
                $itemTypes = ['flight'];
                $filterLabel = 'Pesawat';
                break;
            case 'vehicle':
                $itemTypes = ['bus', 'towing'];
                $filterLabel = 'Kendaraan (Bus/Towing)';
                break;
            case 'rental':
                $itemTypes = ['rental'];
                $filterLabel = 'Rental Mobil';
                break;
            default:
                $itemTypes = ['hotel', 'flight', 'bus', 'towing', 'rental'];
                $filterLabel = 'Semua';
        }
        
        $itemTypesStr = "'" . implode("','", $itemTypes) . "'";
        
        // Get orders with relevant items
        $where = "o.company_id = ? AND o.status NOT IN ('cancelled', 'draft')";
        $params = [$companyId];
        
        if (!empty($search)) {
            $where .= " AND (o.order_number LIKE ? OR o.event_name LIKE ? OR c.name LIKE ?)";
            $params[] = "%{$search}%";
            $params[] = "%{$search}%";
            $params[] = "%{$search}%";
        }
        
        // Count total
        $countSql = "
            SELECT COUNT(DISTINCT o.id) 
            FROM orders o 
            LEFT JOIN clients c ON o.client_id = c.id
            INNER JOIN order_items oi ON o.id = oi.order_id AND oi.item_type IN ({$itemTypesStr})
            WHERE {$where}
        ";
        $total = (int) db()->fetchColumn($countSql, $params);
        
        $offset = ($page - 1) * $perPage;
        
        // Get orders with attachment status
        $sql = "
            SELECT 
                o.id,
                o.order_number,
                o.event_name,
                o.event_date,
                o.event_end_date,
                o.status,
                c.name as client_name,
                GROUP_CONCAT(DISTINCT oi.item_type) as item_types,
                COUNT(DISTINCT CASE WHEN oi.item_type = 'hotel' THEN oi.id END) as hotel_count,
                COUNT(DISTINCT CASE WHEN oi.item_type = 'flight' THEN oi.id END) as flight_count,
                COUNT(DISTINCT CASE WHEN oi.item_type IN ('bus', 'towing') THEN oi.id END) as vehicle_count,
                COUNT(DISTINCT CASE WHEN oi.item_type = 'rental' THEN oi.id END) as rental_count
            FROM orders o
            LEFT JOIN clients c ON o.client_id = c.id
            INNER JOIN order_items oi ON o.id = oi.order_id AND oi.item_type IN ({$itemTypesStr})
            WHERE {$where}
            GROUP BY o.id
            ORDER BY o.event_date DESC, o.created_at DESC
            LIMIT {$perPage} OFFSET {$offset}
        ";
        
        $orders = db()->fetchAll($sql, $params);
        
        // Get attachment status for each order
        foreach ($orders as &$order) {
            $order['attachment_status'] = $this->getAttachmentStatus($order['id']);
        }
        
        $pagination = [
            'total' => $total,
            'per_page' => $perPage,
            'current_page' => $page,
            'last_page' => ceil($total / $perPage) ?: 1,
            'from' => $total > 0 ? $offset + 1 : 0,
            'to' => min($offset + $perPage, $total)
        ];
        
        // Stats
        $stats = $this->getAttachmentStats($companyId);
        
        $data = [
            'pageTitle' => 'Dashboard Lampiran',
            'orders' => $orders,
            'pagination' => $pagination,
            'filter' => $filter,
            'filterLabel' => $filterLabel,
            'search' => $search,
            'stats' => $stats
        ];
        
        render('attachments/dashboard', $data);
    }
    
    /**
     * Get attachment status for an order
     */
    private function getAttachmentStatus(int $orderId): array {
        $status = [
            'hotel' => ['required' => false, 'filled' => false, 'count' => 0],
            'flight' => ['required' => false, 'filled' => false, 'count' => 0],
            'vehicle' => ['required' => false, 'filled' => false, 'count' => 0],
            'rental' => ['required' => false, 'filled' => false, 'count' => 0]
        ];
        
        // Check hotel
        $hotelItems = db()->fetchColumn("SELECT COUNT(*) FROM order_items WHERE order_id = ? AND item_type = 'hotel'", [$orderId]);
        if ($hotelItems > 0) {
            $status['hotel']['required'] = true;
            $status['hotel']['count'] = $hotelItems;
            $hotelGuests = db()->fetchColumn("SELECT COUNT(*) FROM hotel_guests WHERE order_id = ?", [$orderId]);
            $status['hotel']['filled'] = $hotelGuests > 0;
        }
        
        // Check flight
        $flightItems = db()->fetchColumn("SELECT COUNT(*) FROM order_items WHERE order_id = ? AND item_type = 'flight'", [$orderId]);
        if ($flightItems > 0) {
            $status['flight']['required'] = true;
            $status['flight']['count'] = $flightItems;
            try {
                $flightDetails = db()->fetchColumn("SELECT COUNT(*) FROM flight_details WHERE order_id = ?", [$orderId]);
                $status['flight']['filled'] = $flightDetails > 0;
            } catch (Exception $e) {
                $status['flight']['filled'] = false;
            }
        }
        
        // Check vehicle (bus, towing)
        $vehicleItems = db()->fetchColumn("SELECT COUNT(*) FROM order_items WHERE order_id = ? AND item_type IN ('bus', 'towing')", [$orderId]);
        if ($vehicleItems > 0) {
            $status['vehicle']['required'] = true;
            $status['vehicle']['count'] = $vehicleItems;
            try {
                $vehicleDocs = db()->fetchColumn("SELECT COUNT(*) FROM vehicle_documents WHERE order_id = ?", [$orderId]);
                $status['vehicle']['filled'] = $vehicleDocs > 0;
            } catch (Exception $e) {
                $status['vehicle']['filled'] = false;
            }
        }
        
        // Check rental
        $rentalItems = db()->fetchColumn("SELECT COUNT(*) FROM order_items WHERE order_id = ? AND item_type = 'rental'", [$orderId]);
        if ($rentalItems > 0) {
            $status['rental']['required'] = true;
            $status['rental']['count'] = $rentalItems;
            try {
                $rentalDetails = db()->fetchColumn("SELECT COUNT(*) FROM rental_details WHERE order_id = ?", [$orderId]);
                $status['rental']['filled'] = $rentalDetails > 0;
            } catch (Exception $e) {
                $status['rental']['filled'] = false;
            }
        }
        
        return $status;
    }
    
    /**
     * Get overall attachment stats
     */
    private function getAttachmentStats(int $companyId): array {
        $stats = [
            'total_orders' => 0,
            'pending_hotel' => 0,
            'pending_flight' => 0,
            'pending_vehicle' => 0,
            'pending_rental' => 0,
            'completed' => 0
        ];
        
        // Total orders with attachments needed
        $stats['total_orders'] = (int) db()->fetchColumn("
            SELECT COUNT(DISTINCT o.id) FROM orders o
            INNER JOIN order_items oi ON o.id = oi.order_id 
            WHERE o.company_id = ? AND o.status NOT IN ('cancelled', 'draft')
            AND oi.item_type IN ('hotel', 'flight', 'bus', 'towing', 'rental')
        ", [$companyId]);
        
        // Pending hotel (has hotel items but no guests)
        $stats['pending_hotel'] = (int) db()->fetchColumn("
            SELECT COUNT(DISTINCT o.id) FROM orders o
            INNER JOIN order_items oi ON o.id = oi.order_id AND oi.item_type = 'hotel'
            LEFT JOIN hotel_guests hg ON o.id = hg.order_id
            WHERE o.company_id = ? AND o.status NOT IN ('cancelled', 'draft')
            AND hg.id IS NULL
        ", [$companyId]);
        
        // Pending flight
        try {
            $stats['pending_flight'] = (int) db()->fetchColumn("
                SELECT COUNT(DISTINCT o.id) FROM orders o
                INNER JOIN order_items oi ON o.id = oi.order_id AND oi.item_type = 'flight'
                LEFT JOIN flight_details fd ON o.id = fd.order_id
                WHERE o.company_id = ? AND o.status NOT IN ('cancelled', 'draft')
                AND fd.id IS NULL
            ", [$companyId]);
        } catch (Exception $e) {}
        
        // Pending vehicle
        try {
            $stats['pending_vehicle'] = (int) db()->fetchColumn("
                SELECT COUNT(DISTINCT o.id) FROM orders o
                INNER JOIN order_items oi ON o.id = oi.order_id AND oi.item_type IN ('bus', 'towing')
                LEFT JOIN vehicle_documents vd ON o.id = vd.order_id
                WHERE o.company_id = ? AND o.status NOT IN ('cancelled', 'draft')
                AND vd.id IS NULL
            ", [$companyId]);
        } catch (Exception $e) {}
        
        // Pending rental
        try {
            $stats['pending_rental'] = (int) db()->fetchColumn("
                SELECT COUNT(DISTINCT o.id) FROM orders o
                INNER JOIN order_items oi ON o.id = oi.order_id AND oi.item_type = 'rental'
                LEFT JOIN rental_details rd ON o.id = rd.order_id
                WHERE o.company_id = ? AND o.status NOT IN ('cancelled', 'draft')
                AND rd.id IS NULL
            ", [$companyId]);
        } catch (Exception $e) {}
        
        return $stats;
    }
    
    /**
     * View order detail (limited - tanpa harga)
     */
    public function viewOrder(int $id): void {
        $companyId = Session::companyId();
        
        $order = db()->fetchOne("
            SELECT o.*, c.name as client_name 
            FROM orders o 
            LEFT JOIN clients c ON o.client_id = c.id 
            WHERE o.id = ? AND o.company_id = ?
        ", [$id, $companyId]);
        
        if (!$order) {
            Session::flash('error', 'Pesanan tidak ditemukan.');
            redirect('/attachment-dashboard');
            return;
        }
        
        // Get items (without price details for attachment role)
        $items = db()->fetchAll("
            SELECT id, item_type, description, quantity, num_days, hotel_name, room_type, 
                   check_in_date, check_out_date, vehicle_plate, attachment_logo
            FROM order_items 
            WHERE order_id = ? 
            ORDER BY id
        ", [$id]);
        
        // Group items by type
        $groupedItems = [
            'hotel' => [],
            'flight' => [],
            'vehicle' => [],
            'rental' => []
        ];
        
        foreach ($items as $item) {
            switch ($item['item_type']) {
                case 'hotel':
                    $groupedItems['hotel'][] = $item;
                    break;
                case 'flight':
                    $groupedItems['flight'][] = $item;
                    break;
                case 'bus':
                case 'towing':
                    $groupedItems['vehicle'][] = $item;
                    break;
                case 'rental':
                    $groupedItems['rental'][] = $item;
                    break;
            }
        }
        
        // Get attachment status
        $attachmentStatus = $this->getAttachmentStatus($id);
        
        $data = [
            'pageTitle' => 'Detail Pesanan - ' . $order['order_number'],
            'order' => $order,
            'items' => $items,
            'groupedItems' => $groupedItems,
            'attachmentStatus' => $attachmentStatus
        ];
        
        render('attachments/order-detail', $data);
    }
}
