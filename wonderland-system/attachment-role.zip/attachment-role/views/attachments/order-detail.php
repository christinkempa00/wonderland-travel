<?php
/**
 * Attachment Order Detail View
 * Detail pesanan untuk Staff Lampiran (tanpa informasi harga)
 */
?>

<div class="attachment-order-detail">
    <!-- Header -->
    <div class="page-header mb-4">
        <div class="row align-items-center">
            <div class="col">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-2">
                        <li class="breadcrumb-item">
                            <a href="<?= url('/attachment-dashboard') ?>">Dashboard Lampiran</a>
                        </li>
                        <li class="breadcrumb-item active"><?= e($order['order_number']) ?></li>
                    </ol>
                </nav>
                <h1 class="page-title">
                    <i class="fas fa-file-alt text-primary"></i>
                    <?= e($order['order_number']) ?>
                </h1>
            </div>
            <div class="col-auto">
                <a href="<?= url('/attachment-dashboard') ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
    </div>
    
    <!-- Order Info -->
    <div class="glass-card mb-4">
        <div class="card-header-custom">
            <h5 class="mb-0"><i class="fas fa-info-circle text-primary"></i> Informasi Pesanan</h5>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-6">
                    <table class="table table-borderless table-sm mb-0">
                        <tr>
                            <td class="text-muted" style="width: 140px;">No. Pesanan</td>
                            <td><strong><?= e($order['order_number']) ?></strong></td>
                        </tr>
                        <tr>
                            <td class="text-muted">Klien</td>
                            <td><?= e($order['client_name'] ?? '-') ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted">Event</td>
                            <td><?= e($order['event_name'] ?? '-') ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-borderless table-sm mb-0">
                        <tr>
                            <td class="text-muted" style="width: 140px;">Tanggal Event</td>
                            <td>
                                <?php if ($order['event_date']): ?>
                                <?= formatDateIndo($order['event_date']) ?>
                                <?php if ($order['event_end_date'] && $order['event_end_date'] !== $order['event_date']): ?>
                                s/d <?= formatDateIndo($order['event_end_date']) ?>
                                <?php endif; ?>
                                <?php else: ?>
                                -
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-muted">Status</td>
                            <td>
                                <?php
                                $statusColors = [
                                    'draft' => 'secondary',
                                    'quotation' => 'info',
                                    'agreed' => 'primary',
                                    'invoiced' => 'warning',
                                    'paid' => 'success',
                                    'completed' => 'success',
                                    'cancelled' => 'danger'
                                ];
                                $color = $statusColors[$order['status']] ?? 'secondary';
                                ?>
                                <span class="badge bg-<?= $color ?>"><?= ucfirst($order['status']) ?></span>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Attachment Sections -->
    <div class="row g-4">
        
        <!-- Hotel Section -->
        <?php if (!empty($groupedItems['hotel'])): ?>
        <div class="col-md-6">
            <div class="glass-card h-100">
                <div class="card-header-custom d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="fas fa-hotel text-warning"></i> 
                        Hotel
                        <span class="badge bg-<?= $attachmentStatus['hotel']['filled'] ? 'success' : 'warning' ?> ms-2">
                            <?= $attachmentStatus['hotel']['filled'] ? 'Sudah Diisi' : 'Belum Diisi' ?>
                        </span>
                    </h5>
                </div>
                <div class="card-body">
                    <?php foreach ($groupedItems['hotel'] as $item): ?>
                    <div class="attachment-item">
                        <div class="item-info">
                            <strong><?= e($item['hotel_name'] ?: $item['description']) ?></strong>
                            <div class="text-muted small">
                                <?php if ($item['room_type']): ?>
                                <span><i class="fas fa-bed"></i> <?= e($item['room_type']) ?></span>
                                <?php endif; ?>
                                <?php if ($item['check_in_date']): ?>
                                <span class="ms-2"><i class="fas fa-calendar"></i> <?= formatDateIndo($item['check_in_date']) ?></span>
                                <?php endif; ?>
                                <span class="ms-2"><i class="fas fa-door-open"></i> <?= $item['quantity'] ?> kamar × <?= $item['num_days'] ?> malam</span>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    
                    <div class="mt-3">
                        <a href="<?= url('/orders/' . $order['id'] . '/hotel-guests') ?>" class="btn btn-primary w-100">
                            <i class="fas fa-edit"></i> Input Data Tamu Hotel
                        </a>
                        <?php if ($attachmentStatus['hotel']['filled']): ?>
                        <a href="<?= url('/orders/' . $order['id'] . '/hotel-attachment') ?>" class="btn btn-outline-secondary w-100 mt-2" target="_blank">
                            <i class="fas fa-print"></i> Cetak Lampiran
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Flight Section -->
        <?php if (!empty($groupedItems['flight'])): ?>
        <div class="col-md-6">
            <div class="glass-card h-100">
                <div class="card-header-custom d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="fas fa-plane text-info"></i> 
                        Pesawat
                        <span class="badge bg-<?= $attachmentStatus['flight']['filled'] ? 'success' : 'warning' ?> ms-2">
                            <?= $attachmentStatus['flight']['filled'] ? 'Sudah Diisi' : 'Belum Diisi' ?>
                        </span>
                    </h5>
                </div>
                <div class="card-body">
                    <?php foreach ($groupedItems['flight'] as $item): ?>
                    <div class="attachment-item">
                        <div class="item-info">
                            <strong><?= e($item['description']) ?></strong>
                            <div class="text-muted small">
                                <span><i class="fas fa-ticket-alt"></i> <?= $item['quantity'] ?> tiket</span>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    
                    <div class="mt-3">
                        <a href="<?= url('/orders/' . $order['id'] . '/flight-guests') ?>" class="btn btn-primary w-100">
                            <i class="fas fa-edit"></i> Input Data Penumpang
                        </a>
                        <?php if ($attachmentStatus['flight']['filled']): ?>
                        <a href="<?= url('/orders/' . $order['id'] . '/flight-attachment') ?>" class="btn btn-outline-secondary w-100 mt-2" target="_blank">
                            <i class="fas fa-print"></i> Cetak Lampiran
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Vehicle Section (Bus/Towing) -->
        <?php if (!empty($groupedItems['vehicle'])): ?>
        <div class="col-md-6">
            <div class="glass-card h-100">
                <div class="card-header-custom d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="fas fa-bus text-danger"></i> 
                        Kendaraan (Bus/Towing)
                        <span class="badge bg-<?= $attachmentStatus['vehicle']['filled'] ? 'success' : 'warning' ?> ms-2">
                            <?= $attachmentStatus['vehicle']['filled'] ? 'Sudah Diisi' : 'Belum Diisi' ?>
                        </span>
                    </h5>
                </div>
                <div class="card-body">
                    <?php foreach ($groupedItems['vehicle'] as $item): ?>
                    <div class="attachment-item">
                        <div class="item-info">
                            <strong><?= e($item['description']) ?></strong>
                            <div class="text-muted small">
                                <span><i class="fas fa-<?= $item['item_type'] === 'bus' ? 'bus' : 'truck' ?>"></i> <?= ucfirst($item['item_type']) ?></span>
                                <span class="ms-2"><i class="fas fa-hashtag"></i> <?= $item['quantity'] ?> unit × <?= $item['num_days'] ?> hari</span>
                                <?php if ($item['vehicle_plate']): ?>
                                <span class="ms-2"><i class="fas fa-id-card"></i> <?= e($item['vehicle_plate']) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    
                    <div class="mt-3">
                        <a href="<?= url('/orders/' . $order['id'] . '/vehicle-documents') ?>" class="btn btn-primary w-100">
                            <i class="fas fa-edit"></i> Input Data Kendaraan
                        </a>
                        <?php if ($attachmentStatus['vehicle']['filled']): ?>
                        <a href="<?= url('/orders/' . $order['id'] . '/vehicle-documents-print') ?>" class="btn btn-outline-secondary w-100 mt-2" target="_blank">
                            <i class="fas fa-print"></i> Cetak Lampiran
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Rental Section -->
        <?php if (!empty($groupedItems['rental'])): ?>
        <div class="col-md-6">
            <div class="glass-card h-100">
                <div class="card-header-custom d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="fas fa-car text-success"></i> 
                        Rental Mobil
                        <span class="badge bg-<?= $attachmentStatus['rental']['filled'] ? 'success' : 'warning' ?> ms-2">
                            <?= $attachmentStatus['rental']['filled'] ? 'Sudah Diisi' : 'Belum Diisi' ?>
                        </span>
                    </h5>
                </div>
                <div class="card-body">
                    <?php foreach ($groupedItems['rental'] as $item): ?>
                    <div class="attachment-item">
                        <div class="item-info">
                            <strong><?= e($item['description']) ?></strong>
                            <div class="text-muted small">
                                <span><i class="fas fa-car"></i> <?= $item['quantity'] ?> unit × <?= $item['num_days'] ?> hari</span>
                                <?php if ($item['vehicle_plate']): ?>
                                <span class="ms-2"><i class="fas fa-id-card"></i> <?= e($item['vehicle_plate']) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    
                    <div class="mt-3">
                        <a href="<?= url('/orders/' . $order['id'] . '/rental-vehicles') ?>" class="btn btn-primary w-100">
                            <i class="fas fa-edit"></i> Input Data Rental
                        </a>
                        <?php if ($attachmentStatus['rental']['filled']): ?>
                        <a href="<?= url('/orders/' . $order['id'] . '/rental-attachment') ?>" class="btn btn-outline-secondary w-100 mt-2" target="_blank">
                            <i class="fas fa-print"></i> Cetak Lampiran
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
    </div>
</div>

<style>
.card-header-custom {
    padding: 16px 20px;
    border-bottom: 1px solid #e5e7eb;
    background: #f9fafb;
    border-radius: 12px 12px 0 0;
}

.card-body {
    padding: 20px;
}

.attachment-item {
    padding: 12px;
    background: #f9fafb;
    border-radius: 8px;
    margin-bottom: 10px;
}

.attachment-item:last-child {
    margin-bottom: 0;
}

.item-info strong {
    display: block;
    margin-bottom: 4px;
}

.breadcrumb {
    background: transparent;
    padding: 0;
    margin: 0;
    font-size: 0.85rem;
}

.breadcrumb-item a {
    color: #6b7280;
    text-decoration: none;
}

.breadcrumb-item a:hover {
    color: #3b82f6;
}

.breadcrumb-item.active {
    color: #1f2937;
}
</style>
