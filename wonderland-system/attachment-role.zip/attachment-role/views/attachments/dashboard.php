<?php
/**
 * Attachment Dashboard View
 * Dashboard khusus untuk Staff Lampiran
 */
?>

<div class="attachment-dashboard">
    <!-- Header -->
    <div class="page-header mb-4">
        <div class="row align-items-center">
            <div class="col">
                <h1 class="page-title">
                    <i class="fas fa-clipboard-list text-primary"></i>
                    Dashboard Lampiran
                </h1>
                <p class="page-subtitle text-muted">Kelola data lampiran pesanan</p>
            </div>
        </div>
    </div>
    
    <!-- Stats Cards -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-lg-3">
            <div class="stat-card">
                <div class="stat-icon bg-primary-soft">
                    <i class="fas fa-file-alt text-primary"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-value"><?= $stats['total_orders'] ?></div>
                    <div class="stat-label">Total Pesanan</div>
                </div>
            </div>
        </div>
        
        <div class="col-6 col-lg-3">
            <a href="<?= url('/attachment-dashboard?filter=hotel') ?>" class="stat-card stat-card-link">
                <div class="stat-icon bg-warning-soft">
                    <i class="fas fa-hotel text-warning"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-value"><?= $stats['pending_hotel'] ?></div>
                    <div class="stat-label">Hotel Pending</div>
                </div>
            </a>
        </div>
        
        <div class="col-6 col-lg-3">
            <a href="<?= url('/attachment-dashboard?filter=flight') ?>" class="stat-card stat-card-link">
                <div class="stat-icon bg-info-soft">
                    <i class="fas fa-plane text-info"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-value"><?= $stats['pending_flight'] ?></div>
                    <div class="stat-label">Pesawat Pending</div>
                </div>
            </a>
        </div>
        
        <div class="col-6 col-lg-3">
            <a href="<?= url('/attachment-dashboard?filter=vehicle') ?>" class="stat-card stat-card-link">
                <div class="stat-icon bg-danger-soft">
                    <i class="fas fa-bus text-danger"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-value"><?= $stats['pending_vehicle'] ?></div>
                    <div class="stat-label">Kendaraan Pending</div>
                </div>
            </a>
        </div>
    </div>
    
    <!-- Filter & Search -->
    <div class="glass-card mb-4">
        <form method="get" class="row g-3 align-items-end">
            <div class="col-md-4">
                <label class="form-label">Filter Tipe</label>
                <select name="filter" class="form-select" onchange="this.form.submit()">
                    <option value="all" <?= $filter === 'all' ? 'selected' : '' ?>>Semua Tipe</option>
                    <option value="hotel" <?= $filter === 'hotel' ? 'selected' : '' ?>>Hotel</option>
                    <option value="flight" <?= $filter === 'flight' ? 'selected' : '' ?>>Pesawat</option>
                    <option value="vehicle" <?= $filter === 'vehicle' ? 'selected' : '' ?>>Kendaraan (Bus/Towing)</option>
                    <option value="rental" <?= $filter === 'rental' ? 'selected' : '' ?>>Rental Mobil</option>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Cari</label>
                <div class="input-group">
                    <input type="text" name="search" class="form-control" 
                           placeholder="No. Pesanan, Event, atau Klien..."
                           value="<?= e($search) ?>">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>
            <div class="col-md-2">
                <?php if (!empty($search) || $filter !== 'all'): ?>
                <a href="<?= url('/attachment-dashboard') ?>" class="btn btn-outline-secondary w-100">
                    <i class="fas fa-times"></i> Reset
                </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    
    <!-- Filter Label -->
    <?php if ($filter !== 'all'): ?>
    <div class="alert alert-info mb-4">
        <i class="fas fa-filter"></i>
        Menampilkan pesanan dengan item: <strong><?= e($filterLabel) ?></strong>
    </div>
    <?php endif; ?>
    
    <!-- Orders List -->
    <div class="glass-card">
        <?php if (empty($orders)): ?>
        <div class="empty-state py-5">
            <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
            <h5>Tidak Ada Pesanan</h5>
            <p class="text-muted">Tidak ditemukan pesanan yang memerlukan input lampiran.</p>
        </div>
        <?php else: ?>
        
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No. Pesanan</th>
                        <th>Klien / Event</th>
                        <th>Tanggal</th>
                        <th class="text-center">Lampiran</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                    <tr>
                        <td>
                            <strong><?= e($order['order_number']) ?></strong>
                        </td>
                        <td>
                            <div><?= e($order['client_name'] ?? '-') ?></div>
                            <?php if ($order['event_name']): ?>
                            <small class="text-muted"><?= e($order['event_name']) ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($order['event_date']): ?>
                            <?= formatDateIndo($order['event_date']) ?>
                            <?php if ($order['event_end_date'] && $order['event_end_date'] !== $order['event_date']): ?>
                            <br><small class="text-muted">s/d <?= formatDateIndo($order['event_end_date']) ?></small>
                            <?php endif; ?>
                            <?php else: ?>
                            <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <!-- Attachment Type Badges -->
                            <div class="attachment-badges">
                                <?php if ($order['attachment_status']['hotel']['required']): ?>
                                <span class="badge-attachment <?= $order['attachment_status']['hotel']['filled'] ? 'filled' : 'pending' ?>" 
                                      title="Hotel: <?= $order['attachment_status']['hotel']['filled'] ? 'Sudah diisi' : 'Belum diisi' ?>">
                                    <i class="fas fa-hotel"></i>
                                </span>
                                <?php endif; ?>
                                
                                <?php if ($order['attachment_status']['flight']['required']): ?>
                                <span class="badge-attachment <?= $order['attachment_status']['flight']['filled'] ? 'filled' : 'pending' ?>"
                                      title="Pesawat: <?= $order['attachment_status']['flight']['filled'] ? 'Sudah diisi' : 'Belum diisi' ?>">
                                    <i class="fas fa-plane"></i>
                                </span>
                                <?php endif; ?>
                                
                                <?php if ($order['attachment_status']['vehicle']['required']): ?>
                                <span class="badge-attachment <?= $order['attachment_status']['vehicle']['filled'] ? 'filled' : 'pending' ?>"
                                      title="Kendaraan: <?= $order['attachment_status']['vehicle']['filled'] ? 'Sudah diisi' : 'Belum diisi' ?>">
                                    <i class="fas fa-bus"></i>
                                </span>
                                <?php endif; ?>
                                
                                <?php if ($order['attachment_status']['rental']['required']): ?>
                                <span class="badge-attachment <?= $order['attachment_status']['rental']['filled'] ? 'filled' : 'pending' ?>"
                                      title="Rental: <?= $order['attachment_status']['rental']['filled'] ? 'Sudah diisi' : 'Belum diisi' ?>">
                                    <i class="fas fa-car"></i>
                                </span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td class="text-center">
                            <?php
                            $allFilled = true;
                            $anyRequired = false;
                            foreach ($order['attachment_status'] as $type => $status) {
                                if ($status['required']) {
                                    $anyRequired = true;
                                    if (!$status['filled']) {
                                        $allFilled = false;
                                    }
                                }
                            }
                            ?>
                            <?php if ($allFilled && $anyRequired): ?>
                            <span class="badge bg-success">
                                <i class="fas fa-check"></i> Lengkap
                            </span>
                            <?php else: ?>
                            <span class="badge bg-warning text-dark">
                                <i class="fas fa-clock"></i> Pending
                            </span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <div class="btn-group">
                                <a href="<?= url('/attachment-order/' . $order['id']) ?>" 
                                   class="btn btn-sm btn-primary" title="Input Lampiran">
                                    <i class="fas fa-edit"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <?php if ($pagination['last_page'] > 1): ?>
        <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
            <div class="text-muted">
                Menampilkan <?= $pagination['from'] ?> - <?= $pagination['to'] ?> dari <?= $pagination['total'] ?> pesanan
            </div>
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if ($pagination['current_page'] > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?= $pagination['current_page'] - 1 ?>&filter=<?= $filter ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $pagination['current_page'] - 2); $i <= min($pagination['last_page'], $pagination['current_page'] + 2); $i++): ?>
                    <li class="page-item <?= $i === $pagination['current_page'] ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>&filter=<?= $filter ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
                    </li>
                    <?php endfor; ?>
                    
                    <?php if ($pagination['current_page'] < $pagination['last_page']): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?= $pagination['current_page'] + 1 ?>&filter=<?= $filter ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
        
        <?php endif; ?>
    </div>
</div>

<style>
/* Stat Cards */
.stat-card {
    background: white;
    border-radius: 12px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    transition: all 0.2s;
    text-decoration: none;
    color: inherit;
}

.stat-card-link:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
}

.bg-primary-soft { background: rgba(59, 130, 246, 0.1); }
.bg-warning-soft { background: rgba(245, 158, 11, 0.1); }
.bg-info-soft { background: rgba(6, 182, 212, 0.1); }
.bg-danger-soft { background: rgba(239, 68, 68, 0.1); }
.bg-success-soft { background: rgba(34, 197, 94, 0.1); }

.stat-value {
    font-size: 1.5rem;
    font-weight: 700;
    color: #1f2937;
}

.stat-label {
    font-size: 0.8rem;
    color: #6b7280;
}

/* Attachment Badges */
.attachment-badges {
    display: flex;
    gap: 6px;
    justify-content: center;
    flex-wrap: wrap;
}

.badge-attachment {
    width: 28px;
    height: 28px;
    border-radius: 6px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 0.75rem;
    cursor: help;
}

.badge-attachment.filled {
    background: rgba(34, 197, 94, 0.15);
    color: #16a34a;
}

.badge-attachment.pending {
    background: rgba(245, 158, 11, 0.15);
    color: #d97706;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 40px 20px;
}

.empty-state i {
    opacity: 0.3;
}

/* Table */
.table th {
    font-weight: 600;
    font-size: 0.8rem;
    text-transform: uppercase;
    color: #6b7280;
    border-bottom: 2px solid #e5e7eb;
}

.table td {
    vertical-align: middle;
    padding: 16px 12px;
}
</style>
