<?php
/**
 * ================================================================
 * TRAVEL MANAGEMENT SYSTEM - Accounting Helper
 * ================================================================
 * 
 * File: /helpers/AccountingHelper.php
 * 
 * CARA PAKAI:
 * Tambahkan di config/bootstrap.php atau di controller yang membutuhkan:
 * require_once HELPERS_PATH . '/AccountingHelper.php';
 */

// Prevent direct access
if (!defined('BASE_PATH')) {
    exit('No direct script access allowed');
}

/**
 * Get accounting setting (default account)
 */
function getAccountingSetting(int $companyId, string $key): ?int {
    try {
        $result = db()->fetchOne(
            "SELECT account_id FROM accounting_settings WHERE company_id = ? AND setting_key = ?",
            [$companyId, $key]
        );
        return $result ? (int)$result['account_id'] : null;
    } catch (Exception $e) {
        return null;
    }
}

/**
 * Set accounting setting
 */
function setAccountingSetting(int $companyId, string $key, ?int $accountId, ?string $description = null): void {
    try {
        $existing = db()->fetchOne(
            "SELECT id FROM accounting_settings WHERE company_id = ? AND setting_key = ?",
            [$companyId, $key]
        );
        
        if ($existing) {
            db()->update('accounting_settings', [
                'account_id' => $accountId,
                'description' => $description
            ], 'id = ?', [$existing['id']]);
        } else {
            db()->insert('accounting_settings', [
                'company_id' => $companyId,
                'setting_key' => $key,
                'account_id' => $accountId,
                'description' => $description
            ]);
        }
    } catch (Exception $e) {
        error_log("setAccountingSetting error: " . $e->getMessage());
    }
}

/**
 * Get revenue account based on service type
 */
function getRevenueAccount(int $companyId, string $serviceType): ?int {
    $mapping = [
        'bus' => 'revenue_bus',
        'towing' => 'revenue_towing',
        'hotel' => 'revenue_hotel',
        'travel' => 'revenue_travel',
        'rental' => 'revenue_rental',
        'flight' => 'revenue_travel'
    ];
    
    $key = $mapping[$serviceType] ?? 'revenue_bus';
    $accountId = getAccountingSetting($companyId, $key);
    
    // Fallback to general revenue if specific not found
    if (!$accountId) {
        $accountId = getAccountingSetting($companyId, 'revenue_bus');
    }
    
    return $accountId;
}

/**
 * Generate journal number
 */
function generateJournalNumber(int $companyId, string $type = 'JU'): string {
    $year = date('y');
    $month = date('m');
    
    try {
        $lastJournal = db()->fetchOne(
            "SELECT journal_number FROM journals 
             WHERE company_id = ? 
             AND journal_number LIKE ? 
             ORDER BY id DESC LIMIT 1",
            [$companyId, $type . '/' . $year . $month . '/%']
        );
        
        if ($lastJournal) {
            $parts = explode('/', $lastJournal['journal_number']);
            $lastNum = (int)end($parts);
            $newNum = $lastNum + 1;
        } else {
            $newNum = 1;
        }
    } catch (Exception $e) {
        $newNum = 1;
    }
    
    return $type . '/' . $year . $month . '/' . str_pad($newNum, 4, '0', STR_PAD_LEFT);
}

/**
 * Create journal for order invoice
 * Called when order status changes to 'invoiced'
 * 
 * Jurnal:
 *   Debit:  Piutang Usaha      Rp XXX
 *   Credit: Pendapatan Jasa    Rp XXX
 */
function createOrderInvoiceJournal(array $order): ?int {
    $companyId = (int)$order['company_id'];
    $orderId = (int)$order['id'];
    $amount = (float)$order['total_final_price'];
    
    if ($amount <= 0) {
        return null;
    }
    
    // Get accounts
    $receivableAccountId = getAccountingSetting($companyId, 'account_receivable');
    $revenueAccountId = getRevenueAccount($companyId, $order['service_type'] ?? 'bus');
    
    if (!$receivableAccountId || !$revenueAccountId) {
        error_log("Accounting settings not configured for company {$companyId}");
        return null;
    }
    
    // Check if journal already exists
    try {
        $existing = db()->fetchOne(
            "SELECT id FROM journals WHERE order_id = ? AND journal_type = 'order_invoice'",
            [$orderId]
        );
        
        if ($existing) {
            return (int)$existing['id'];
        }
    } catch (Exception $e) {
        // Column might not exist yet, continue
    }
    
    try {
        $journalNumber = generateJournalNumber($companyId, 'JU');
        $userId = Session::userId() ?? 1;
        
        // Create journal header
        $journalId = db()->insert('journals', [
            'company_id' => $companyId,
            'order_id' => $orderId,
            'journal_number' => $journalNumber,
            'journal_type' => 'order_invoice',
            'journal_date' => date('Y-m-d'),
            'description' => 'Invoice Order: ' . ($order['order_number'] ?? '') . ' - ' . ($order['event_name'] ?? 'N/A'),
            'reference' => $order['order_number'] ?? '',
            'status' => 'posted',
            'posted_at' => date('Y-m-d H:i:s'),
            'posted_by' => $userId,
            'created_by' => $userId
        ]);
        
        // Create journal details - Debit: Piutang
        db()->insert('journal_details', [
            'journal_id' => $journalId,
            'account_id' => $receivableAccountId,
            'description' => 'Piutang dari ' . ($order['order_number'] ?? ''),
            'debit' => $amount,
            'credit' => 0
        ]);
        
        // Credit: Pendapatan
        db()->insert('journal_details', [
            'journal_id' => $journalId,
            'account_id' => $revenueAccountId,
            'description' => 'Pendapatan ' . ($order['order_number'] ?? ''),
            'debit' => 0,
            'credit' => $amount
        ]);
        
        // Update order with journal reference
        try {
            db()->update('orders', [
                'invoice_journal_id' => $journalId
            ], 'id = ?', [$orderId]);
        } catch (Exception $e) {
            // Column might not exist
        }
        
        return $journalId;
        
    } catch (Exception $e) {
        error_log("Failed to create invoice journal: " . $e->getMessage());
        return null;
    }
}

/**
 * Create journal for order payment
 * 
 * Jurnal:
 *   Debit:  Kas/Bank           Rp XXX
 *   Credit: Piutang Usaha      Rp XXX
 */
function createOrderPaymentJournal(
    array $order, 
    float $paymentAmount,
    string $paymentMethod = 'transfer',
    ?int $bankCashId = null,
    ?string $reference = null,
    ?string $notes = null
): array {
    $companyId = (int)$order['company_id'];
    $orderId = (int)$order['id'];
    
    if ($paymentAmount <= 0) {
        return ['success' => false, 'message' => 'Jumlah pembayaran harus lebih dari 0'];
    }
    
    // Get accounts
    $receivableAccountId = getAccountingSetting($companyId, 'account_receivable');
    
    // Determine cash/bank account
    $cashBankAccountId = null;
    if ($bankCashId) {
        try {
            $bankCash = db()->fetchOne("SELECT account_id FROM bank_cash WHERE id = ?", [$bankCashId]);
            $cashBankAccountId = $bankCash ? (int)$bankCash['account_id'] : null;
        } catch (Exception $e) {}
    }
    
    if (!$cashBankAccountId) {
        $settingKey = $paymentMethod === 'cash' ? 'default_cash' : 'default_bank';
        $cashBankAccountId = getAccountingSetting($companyId, $settingKey);
    }
    
    if (!$receivableAccountId || !$cashBankAccountId) {
        return ['success' => false, 'message' => 'Pengaturan akun akuntansi belum dikonfigurasi. Silakan setup di menu Akuntansi > Settings.'];
    }
    
    try {
        $journalNumber = generateJournalNumber($companyId, 'JKM');
        $userId = Session::userId() ?? 1;
        
        // Create journal header
        $journalId = db()->insert('journals', [
            'company_id' => $companyId,
            'order_id' => $orderId,
            'journal_number' => $journalNumber,
            'journal_type' => 'order_payment',
            'journal_date' => date('Y-m-d'),
            'description' => 'Pembayaran Order: ' . ($order['order_number'] ?? '') . ' - ' . ($order['event_name'] ?? 'N/A'),
            'reference' => $reference ?: ($order['order_number'] ?? ''),
            'status' => 'posted',
            'posted_at' => date('Y-m-d H:i:s'),
            'posted_by' => $userId,
            'created_by' => $userId
        ]);
        
        // Debit: Kas/Bank
        db()->insert('journal_details', [
            'journal_id' => $journalId,
            'account_id' => $cashBankAccountId,
            'description' => 'Penerimaan dari ' . ($order['order_number'] ?? ''),
            'debit' => $paymentAmount,
            'credit' => 0
        ]);
        
        // Credit: Piutang Usaha
        db()->insert('journal_details', [
            'journal_id' => $journalId,
            'account_id' => $receivableAccountId,
            'description' => 'Pelunasan ' . ($order['order_number'] ?? ''),
            'debit' => 0,
            'credit' => $paymentAmount
        ]);
        
        // Create payment record
        $paymentId = db()->insert('order_payments', [
            'order_id' => $orderId,
            'company_id' => $companyId,
            'payment_date' => date('Y-m-d'),
            'amount' => $paymentAmount,
            'payment_method' => $paymentMethod,
            'bank_cash_id' => $bankCashId,
            'reference' => $reference,
            'notes' => $notes,
            'journal_id' => $journalId,
            'created_by' => $userId
        ]);
        
        // Update order paid amount
        $newPaidAmount = (float)($order['paid_amount'] ?? 0) + $paymentAmount;
        $totalPrice = (float)($order['total_final_price'] ?? 0);
        
        if ($newPaidAmount >= $totalPrice) {
            $paymentStatus = 'paid';
            $paidAt = date('Y-m-d');
        } elseif ($newPaidAmount > 0) {
            $paymentStatus = 'partial';
            $paidAt = null;
        } else {
            $paymentStatus = 'unpaid';
            $paidAt = null;
        }
        
        db()->update('orders', [
            'paid_amount' => $newPaidAmount,
            'payment_status' => $paymentStatus,
            'paid_at' => $paidAt
        ], 'id = ?', [$orderId]);
        
        // Update bank_cash balance
        if ($bankCashId) {
            try {
                db()->query(
                    "UPDATE bank_cash SET current_balance = current_balance + ? WHERE id = ?",
                    [$paymentAmount, $bankCashId]
                );
            } catch (Exception $e) {}
        }
        
        return [
            'success' => true,
            'payment_id' => $paymentId,
            'journal_id' => $journalId,
            'message' => 'Pembayaran berhasil dicatat'
        ];
        
    } catch (Exception $e) {
        error_log("Failed to create payment journal: " . $e->getMessage());
        return ['success' => false, 'message' => 'Gagal mencatat pembayaran: ' . $e->getMessage()];
    }
}

/**
 * Get order payment history
 */
function getOrderPayments(int $orderId): array {
    try {
        return db()->fetchAll(
            "SELECT op.*, bc.name as bank_cash_name, j.journal_number,
                    u.name as created_by_name
             FROM order_payments op
             LEFT JOIN bank_cash bc ON op.bank_cash_id = bc.id
             LEFT JOIN journals j ON op.journal_id = j.id
             LEFT JOIN users u ON op.created_by = u.id
             WHERE op.order_id = ?
             ORDER BY op.payment_date DESC, op.id DESC",
            [$orderId]
        );
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Get order remaining amount (unpaid)
 */
function getOrderRemainingAmount(array $order): float {
    $total = (float)($order['total_final_price'] ?? 0);
    $paid = (float)($order['paid_amount'] ?? 0);
    return max(0, $total - $paid);
}

/**
 * Void/cancel a payment
 */
function voidOrderPayment(int $paymentId): array {
    try {
        $payment = db()->fetchOne("SELECT * FROM order_payments WHERE id = ?", [$paymentId]);
        
        if (!$payment) {
            return ['success' => false, 'message' => 'Pembayaran tidak ditemukan'];
        }
        
        $order = db()->fetchOne("SELECT * FROM orders WHERE id = ?", [$payment['order_id']]);
        
        if (!$order) {
            return ['success' => false, 'message' => 'Order tidak ditemukan'];
        }
        
        // Void the journal
        if ($payment['journal_id']) {
            db()->update('journals', [
                'status' => 'void',
                'voided_at' => date('Y-m-d H:i:s'),
                'voided_by' => Session::userId()
            ], 'id = ?', [$payment['journal_id']]);
        }
        
        // Update order
        $newPaidAmount = max(0, (float)$order['paid_amount'] - (float)$payment['amount']);
        $totalPrice = (float)$order['total_final_price'];
        
        if ($newPaidAmount >= $totalPrice) {
            $paymentStatus = 'paid';
        } elseif ($newPaidAmount > 0) {
            $paymentStatus = 'partial';
        } else {
            $paymentStatus = 'unpaid';
        }
        
        db()->update('orders', [
            'paid_amount' => $newPaidAmount,
            'payment_status' => $paymentStatus,
            'paid_at' => $paymentStatus === 'paid' ? $order['paid_at'] : null
        ], 'id = ?', [$order['id']]);
        
        // Update bank balance
        if ($payment['bank_cash_id']) {
            db()->query(
                "UPDATE bank_cash SET current_balance = current_balance - ? WHERE id = ?",
                [$payment['amount'], $payment['bank_cash_id']]
            );
        }
        
        // Delete payment
        db()->delete('order_payments', 'id = ?', [$paymentId]);
        
        return ['success' => true, 'message' => 'Pembayaran berhasil dibatalkan'];
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Gagal: ' . $e->getMessage()];
    }
}

/**
 * Get bank/cash for dropdown
 */
function getBankCashDropdown(int $companyId): array {
    try {
        $items = db()->fetchAll(
            "SELECT id, name, type, current_balance FROM bank_cash 
             WHERE company_id = ? AND is_active = 1 
             ORDER BY type, name",
            [$companyId]
        );
        
        $result = [];
        foreach ($items as $item) {
            $icon = $item['type'] === 'cash' ? '💵' : '🏦';
            $balance = function_exists('formatRupiah') ? formatRupiah($item['current_balance']) : 'Rp ' . number_format($item['current_balance'], 0, ',', '.');
            $result[$item['id']] = $icon . ' ' . $item['name'] . ' (Saldo: ' . $balance . ')';
        }
        
        return $result;
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Get accounts for dropdown
 */
function getAccountsDropdown(int $companyId, ?string $type = null): array {
    try {
        $where = "company_id = ? AND is_active = 1";
        $params = [$companyId];
        
        if ($type) {
            $where .= " AND type = ?";
            $params[] = $type;
        }
        
        $accounts = db()->fetchAll(
            "SELECT id, code, name, type FROM accounts WHERE {$where} ORDER BY code",
            $params
        );
        
        $result = [];
        foreach ($accounts as $acc) {
            $result[$acc['id']] = $acc['code'] . ' - ' . $acc['name'];
        }
        
        return $result;
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Create expense/transaction journal
 * 
 * Jurnal Pengeluaran:
 *   Debit:  Beban XXX           Rp XXX
 *   Credit: Kas/Bank            Rp XXX
 */
function createExpenseJournal(
    int $companyId,
    int $expenseAccountId,
    float $amount,
    string $description,
    ?int $bankCashId = null,
    ?string $reference = null,
    ?string $transactionDate = null
): array {
    if ($amount <= 0) {
        return ['success' => false, 'message' => 'Jumlah harus lebih dari 0'];
    }
    
    // Get cash/bank account
    $cashBankAccountId = null;
    if ($bankCashId) {
        try {
            $bankCash = db()->fetchOne("SELECT account_id FROM bank_cash WHERE id = ?", [$bankCashId]);
            $cashBankAccountId = $bankCash ? (int)$bankCash['account_id'] : null;
        } catch (Exception $e) {}
    }
    
    if (!$cashBankAccountId) {
        $cashBankAccountId = getAccountingSetting($companyId, 'default_cash');
    }
    
    if (!$cashBankAccountId) {
        return ['success' => false, 'message' => 'Akun Kas/Bank belum dikonfigurasi'];
    }
    
    try {
        $journalNumber = generateJournalNumber($companyId, 'JKK'); // Jurnal Kas Keluar
        $userId = Session::userId() ?? 1;
        $date = $transactionDate ?: date('Y-m-d');
        
        // Create journal
        $journalId = db()->insert('journals', [
            'company_id' => $companyId,
            'journal_number' => $journalNumber,
            'journal_type' => 'expense',
            'journal_date' => $date,
            'description' => $description,
            'reference' => $reference,
            'status' => 'posted',
            'posted_at' => date('Y-m-d H:i:s'),
            'posted_by' => $userId,
            'created_by' => $userId
        ]);
        
        // Debit: Beban
        db()->insert('journal_details', [
            'journal_id' => $journalId,
            'account_id' => $expenseAccountId,
            'description' => $description,
            'debit' => $amount,
            'credit' => 0
        ]);
        
        // Credit: Kas/Bank
        db()->insert('journal_details', [
            'journal_id' => $journalId,
            'account_id' => $cashBankAccountId,
            'description' => 'Pembayaran: ' . $description,
            'debit' => 0,
            'credit' => $amount
        ]);
        
        // Update bank_cash balance (decrease)
        if ($bankCashId) {
            db()->query(
                "UPDATE bank_cash SET current_balance = current_balance - ? WHERE id = ?",
                [$amount, $bankCashId]
            );
        }
        
        return [
            'success' => true,
            'journal_id' => $journalId,
            'journal_number' => $journalNumber,
            'message' => 'Transaksi berhasil dicatat'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Gagal: ' . $e->getMessage()];
    }
}

/**
 * Get total receivables
 */
function getTotalReceivables(int $companyId): float {
    try {
        $result = db()->fetchOne(
            "SELECT COALESCE(SUM(total_final_price - paid_amount), 0) as total
             FROM orders 
             WHERE company_id = ? 
             AND payment_status IN ('unpaid', 'partial')
             AND status NOT IN ('cancelled', 'draft')",
            [$companyId]
        );
        return (float)$result['total'];
    } catch (Exception $e) {
        return 0;
    }
}
