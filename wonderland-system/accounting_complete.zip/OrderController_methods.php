<?php
/**
 * ================================================================
 * TAMBAHAN METHOD UNTUK OrderController.php
 * ================================================================
 * 
 * INSTRUKSI INSTALASI:
 * 
 * 1. Buka file /controllers/OrderController.php
 * 
 * 2. Di bagian ATAS file (setelah require models), tambahkan:
 * 
 *    // Load accounting helper
 *    $accountingHelperPath = HELPERS_PATH . '/AccountingHelper.php';
 *    if (file_exists($accountingHelperPath)) {
 *        require_once $accountingHelperPath;
 *    }
 * 
 * 3. Copy 3 method di bawah ini dan paste ke dalam class OrderController
 *    (letakkan sebelum method getPageActions() di akhir file)
 * 
 * 4. Modifikasi method updateStatus() yang sudah ada 
 *    (lihat bagian bawah file ini)
 * 
 * ================================================================
 */

    // ========================================
    // PAYMENT MANAGEMENT (WITH ACCOUNTING)
    // ========================================

    /**
     * Show payment form for an order
     * GET /orders/{id}/payment
     */
    public function payment(int $id): void {
        $order = $this->findOrder($id);
        
        if (!$order) {
            Session::flash('error', 'Pesanan tidak ditemukan.');
            redirect('/orders');
            return;
        }
        
        $companyId = Session::companyId();
        $client = $order->getClient();
        
        // Get payment history
        $payments = [];
        if (function_exists('getOrderPayments')) {
            $payments = getOrderPayments($id);
        }
        
        // Get bank/cash options
        $bankCashOptions = [];
        if (function_exists('getBankCashDropdown')) {
            $bankCashOptions = getBankCashDropdown($companyId);
        } else {
            // Fallback if helper not available
            try {
                $bankCashList = db()->fetchAll(
                    "SELECT id, name, type FROM bank_cash WHERE company_id = ? AND is_active = 1 ORDER BY name",
                    [$companyId]
                );
                foreach ($bankCashList as $bc) {
                    $bankCashOptions[$bc['id']] = ($bc['type'] === 'cash' ? '💵 ' : '🏦 ') . $bc['name'];
                }
            } catch (Exception $e) {}
        }
        
        $data = [
            'pageTitle' => 'Pembayaran - ' . $order->order_number,
            'pageHeader' => true,
            'breadcrumbs' => [
                ['label' => 'Pesanan', 'url' => '/orders'],
                ['label' => $order->order_number, 'url' => '/orders/' . $id],
                ['label' => 'Pembayaran']
            ],
            'order' => $order,
            'client' => $client,
            'payments' => $payments,
            'bankCashOptions' => $bankCashOptions
        ];
        
        render('orders/payment', $data);
    }

    /**
     * Store a payment for an order
     * POST /orders/{id}/payment
     */
    public function storePayment(int $id): void {
        $order = $this->findOrder($id);
        
        if (!$order) {
            Session::flash('error', 'Pesanan tidak ditemukan.');
            redirect('/orders');
            return;
        }
        
        $orderArray = $order->toArray();
        
        // Calculate remaining
        $totalPrice = (float)($orderArray['total_final_price'] ?? 0);
        $paidAmount = (float)($orderArray['paid_amount'] ?? 0);
        $remainingAmount = max(0, $totalPrice - $paidAmount);
        
        // Get input
        $amount = (float) preg_replace('/[^\d]/', '', $_POST['amount'] ?? '0');
        $paymentDate = $_POST['payment_date'] ?? date('Y-m-d');
        $paymentMethod = $_POST['payment_method'] ?? 'transfer';
        $bankCashId = !empty($_POST['bank_cash_id']) ? (int)$_POST['bank_cash_id'] : null;
        $reference = trim($_POST['reference'] ?? '');
        $notes = trim($_POST['notes'] ?? '');
        
        // Validate
        if ($amount <= 0) {
            Session::flash('error', 'Jumlah pembayaran harus lebih dari 0.');
            redirect('/orders/' . $id . '/payment');
            return;
        }
        
        if ($amount > $remainingAmount) {
            Session::flash('error', 'Jumlah pembayaran melebihi sisa tagihan (' . formatRupiah($remainingAmount) . ').');
            redirect('/orders/' . $id . '/payment');
            return;
        }
        
        // Check if accounting helper available
        if (!function_exists('createOrderPaymentJournal')) {
            Session::flash('error', 'AccountingHelper belum di-install. Upload file AccountingHelper.php ke folder /helpers/');
            redirect('/orders/' . $id . '/payment');
            return;
        }
        
        // Ensure invoice journal exists first
        if (empty($orderArray['invoice_journal_id']) && function_exists('createOrderInvoiceJournal')) {
            $invoiceJournalId = createOrderInvoiceJournal($orderArray);
            if ($invoiceJournalId) {
                $orderArray['invoice_journal_id'] = $invoiceJournalId;
            }
        }
        
        // Create payment with journal
        $result = createOrderPaymentJournal(
            $orderArray,
            $amount,
            $paymentMethod,
            $bankCashId,
            $reference,
            $notes
        );
        
        if ($result['success']) {
            Session::flash('success', 'Pembayaran sebesar ' . formatRupiah($amount) . ' berhasil dicatat.');
            
            // Check if now fully paid
            $updatedOrder = $this->findOrder($id);
            if ($updatedOrder && $updatedOrder->payment_status === 'paid') {
                Session::flash('info', '🎉 Order ini sudah LUNAS!');
            }
        } else {
            Session::flash('error', $result['message']);
        }
        
        redirect('/orders/' . $id . '/payment');
    }

    /**
     * Void/cancel a payment
     * POST /orders/{id}/payment/{paymentId}/void
     */
    public function voidPayment(int $id, int $paymentId): void {
        $order = $this->findOrder($id);
        
        if (!$order) {
            Session::flash('error', 'Pesanan tidak ditemukan.');
            redirect('/orders');
            return;
        }
        
        if (!function_exists('voidOrderPayment')) {
            Session::flash('error', 'AccountingHelper belum di-install.');
            redirect('/orders/' . $id . '/payment');
            return;
        }
        
        $result = voidOrderPayment($paymentId);
        
        if ($result['success']) {
            Session::flash('success', $result['message']);
        } else {
            Session::flash('error', $result['message']);
        }
        
        redirect('/orders/' . $id . '/payment');
    }


// ================================================================
// MODIFIKASI METHOD updateStatus()
// ================================================================
// 
// Cari method updateStatus() yang sudah ada di OrderController
// Tambahkan kode berikut SETELAH baris: $order->updateStatus($status);
// 
// KODE YANG PERLU DITAMBAHKAN:
// ================================================================

/*
        // Auto-create invoice journal when status changes to 'invoiced'
        if ($status === 'invoiced' && function_exists('createOrderInvoiceJournal')) {
            try {
                $orderArray = $order->toArray();
                $journalId = createOrderInvoiceJournal($orderArray);
                // Journal created - piutang recorded
            } catch (Exception $e) {
                error_log("Failed to create invoice journal: " . $e->getMessage());
            }
        }
*/

// ================================================================
// CONTOH LENGKAP METHOD updateStatus() YANG SUDAH DIMODIFIKASI:
// ================================================================

    /**
     * Update order status - MODIFIED VERSION
     * Includes auto-create invoice journal
     */
    /*
    public function updateStatus(int $id): void {
        $order = $this->findOrder($id);
        
        if (!$order) {
            jsonError('Pesanan tidak ditemukan.', 404);
            return;
        }
        
        $status = $_POST['status'] ?? '';
        
        if (!isset(ORDER_STATUSES[$status])) {
            jsonError('Status tidak valid.', 400);
            return;
        }
        
        $order->updateStatus($status);
        
        // === TAMBAHAN: Auto-create invoice journal ===
        if ($status === 'invoiced' && function_exists('createOrderInvoiceJournal')) {
            try {
                $orderArray = $order->toArray();
                $journalId = createOrderInvoiceJournal($orderArray);
            } catch (Exception $e) {
                error_log("Failed to create invoice journal: " . $e->getMessage());
            }
        }
        // === END TAMBAHAN ===
        
        logActivity('update_status', 'order', $order->id, 'order', 
            "Changed status to {$status}: " . $order->order_number);
        
        jsonSuccess(['status' => $status, 'label' => ORDER_STATUSES[$status]['label']]);
    }
    */
