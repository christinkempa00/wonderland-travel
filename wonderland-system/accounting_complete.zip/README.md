# 📊 INTEGRASI AKUNTANSI - TRAVEL MANAGEMENT SYSTEM

## 📁 Daftar File

```
├── 01_setup_database.sql      # SQL untuk setup tabel baru
├── 02_migrate_orders.sql      # SQL untuk migrasi order lama ke jurnal
├── AccountingHelper.php       # Helper functions → /helpers/
├── routes.php                 # Routes lengkap → /config/
├── OrderController_methods.php # Method tambahan untuk OrderController
├── TransactionController.php  # Controller transaksi → /controllers/
├── views/
│   ├── orders/
│   │   └── payment.php        # Form pembayaran → /views/orders/
│   └── transactions/
│       ├── index.php          # Daftar transaksi → /views/transactions/
│       ├── form.php           # Form transaksi → /views/transactions/
│       └── show.php           # Detail transaksi → /views/transactions/
```

---

## 🚀 LANGKAH INSTALASI

### Step 1: Setup Database
1. Buka **phpMyAdmin** → database `u251802700_travel`
2. Tab **SQL** → paste isi `01_setup_database.sql` → **Go**
3. Periksa output, pastikan tidak ada error fatal

### Step 2: Upload Files

| File | Upload ke |
|------|-----------|
| `AccountingHelper.php` | `/helpers/AccountingHelper.php` |
| `routes.php` | `/config/routes.php` (replace) |
| `TransactionController.php` | `/controllers/TransactionController.php` |
| `views/orders/payment.php` | `/views/orders/payment.php` |
| `views/transactions/index.php` | `/views/transactions/index.php` |
| `views/transactions/form.php` | `/views/transactions/form.php` |
| `views/transactions/show.php` | `/views/transactions/show.php` |

### Step 3: Update OrderController
1. Buka `/controllers/OrderController.php`
2. Di bagian atas (setelah require models), tambahkan:
```php
// Load accounting helper
$accountingHelperPath = HELPERS_PATH . '/AccountingHelper.php';
if (file_exists($accountingHelperPath)) {
    require_once $accountingHelperPath;
}
```

3. Copy 3 method dari `OrderController_methods.php`:
   - `payment()`
   - `storePayment()`
   - `voidPayment()`
   
   Paste ke dalam class, sebelum `getPageActions()`

4. Modifikasi method `updateStatus()` - tambahkan auto-create journal (lihat file)

### Step 4: Setup Accounting Settings
Jalankan SQL ini di phpMyAdmin setelah mengecek ID akun:
```sql
-- Cek ID akun dulu
SELECT id, code, name FROM accounts WHERE company_id = 1 ORDER BY code;

-- Update settings dengan ID yang benar
UPDATE accounting_settings SET account_id = [ID_PIUTANG] 
WHERE setting_key = 'account_receivable' AND company_id = 1;

-- Dst untuk akun lainnya...
```

### Step 5: Migrasi Order Lama (Opsional)
1. Jalankan `02_migrate_orders.sql` untuk generate jurnal dari order yang sudah ada
2. Atau gunakan procedure: `CALL MigrateOrderToJournal(29);`

---

## ✅ TEST

1. **Test Pembayaran**: Buka `/orders/30/payment`
2. **Test Transaksi**: Buka `/transactions`
3. **Test Pengeluaran**: Buka `/transactions/create?type=expense`

---

## 🔧 TROUBLESHOOTING

### Error 500 di halaman payment
- Pastikan `AccountingHelper.php` sudah ada di `/helpers/`
- Pastikan routes sudah di-update
- Cek error log di hosting

### "Pengaturan akun belum dikonfigurasi"
- Jalankan query UPDATE di Step 4
- Pastikan tabel `accounting_settings` terisi

### Method not found
- Pastikan 3 method sudah di-copy ke OrderController
- Pastikan require AccountingHelper sudah ditambahkan

---

## 📋 FITUR YANG DITAMBAHKAN

1. **Pembayaran Order** (`/orders/{id}/payment`)
   - Input pembayaran dengan auto-generate jurnal
   - Riwayat pembayaran
   - Void pembayaran
   
2. **Transaksi** (`/transactions`)
   - Input pengeluaran operasional
   - Input pemasukan lain-lain
   - Auto-generate jurnal
   - Void transaksi

3. **Jurnal Otomatis**
   - Order → Invoice: Jurnal Piutang
   - Pembayaran: Jurnal Kas Masuk
   - Pengeluaran: Jurnal Kas Keluar

---

## 📊 ALUR JURNAL

### Order di-Invoice
```
Debit:  1.1.03 Piutang Usaha      Rp XXX
Credit: 4.1.01 Pendapatan Jasa    Rp XXX
```

### Pembayaran Diterima
```
Debit:  1.1.01 Kas / 1.1.02 Bank  Rp XXX
Credit: 1.1.03 Piutang Usaha      Rp XXX
```

### Pengeluaran Operasional
```
Debit:  5.1.XX Beban XXX          Rp XXX
Credit: 1.1.01 Kas / 1.1.02 Bank  Rp XXX
```

---

Selesai! 🎉
