-- ================================================================
-- ACCOUNTING INTEGRATION - COMPLETE SQL
-- Travel Management System
-- ================================================================
-- Jalankan di phpMyAdmin satu per satu jika ada error
-- ================================================================

-- ================================================================
-- PART 1: ALTER JOURNALS TABLE
-- ================================================================

-- Tambah kolom order_id dan journal_type ke journals
ALTER TABLE `journals` 
ADD COLUMN IF NOT EXISTS `order_id` INT UNSIGNED NULL AFTER `company_id`,
ADD COLUMN IF NOT EXISTS `journal_type` VARCHAR(50) DEFAULT 'general' AFTER `journal_number`;

-- Tambah index (abaikan error jika sudah ada)
-- ALTER TABLE `journals` ADD KEY `idx_journals_order` (`order_id`);

-- ================================================================
-- PART 2: CREATE accounting_settings TABLE
-- ================================================================

CREATE TABLE IF NOT EXISTS `accounting_settings` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `company_id` INT UNSIGNED NOT NULL,
    `setting_key` VARCHAR(100) NOT NULL,
    `account_id` INT UNSIGNED NULL,
    `setting_value` VARCHAR(255) NULL,
    `description` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `company_setting` (`company_id`, `setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- PART 3: CREATE order_payments TABLE
-- ================================================================

CREATE TABLE IF NOT EXISTS `order_payments` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `order_id` INT UNSIGNED NOT NULL,
    `company_id` INT UNSIGNED NOT NULL,
    `payment_date` DATE NOT NULL,
    `amount` DECIMAL(15,2) NOT NULL,
    `payment_method` ENUM('cash', 'transfer', 'other') DEFAULT 'transfer',
    `bank_cash_id` INT UNSIGNED NULL,
    `reference` VARCHAR(100) NULL,
    `notes` TEXT NULL,
    `journal_id` INT UNSIGNED NULL,
    `created_by` INT UNSIGNED NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_payments_order` (`order_id`),
    KEY `idx_payments_company` (`company_id`),
    KEY `idx_payments_date` (`payment_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- PART 4: CREATE transactions TABLE (untuk pengeluaran operasional)
-- ================================================================

CREATE TABLE IF NOT EXISTS `transactions` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `company_id` INT UNSIGNED NOT NULL,
    `transaction_number` VARCHAR(50) NOT NULL,
    `transaction_date` DATE NOT NULL,
    `transaction_type` ENUM('income', 'expense') NOT NULL DEFAULT 'expense',
    `category` VARCHAR(100) NULL,
    `account_id` INT UNSIGNED NULL COMMENT 'Akun beban/pendapatan',
    `bank_cash_id` INT UNSIGNED NULL COMMENT 'Kas/Bank yang digunakan',
    `amount` DECIMAL(15,2) NOT NULL DEFAULT 0,
    `description` TEXT NULL,
    `reference` VARCHAR(100) NULL,
    `journal_id` INT UNSIGNED NULL,
    `attachment` VARCHAR(255) NULL,
    `status` ENUM('draft', 'posted', 'void') DEFAULT 'posted',
    `created_by` INT UNSIGNED NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_trans_company` (`company_id`),
    KEY `idx_trans_date` (`transaction_date`),
    KEY `idx_trans_type` (`transaction_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- PART 5: ADD invoice_journal_id TO orders (jika belum ada)
-- ================================================================

ALTER TABLE `orders`
ADD COLUMN IF NOT EXISTS `invoice_journal_id` INT UNSIGNED NULL AFTER `notes`;

-- ================================================================
-- PART 6: INSERT DEFAULT ACCOUNTING SETTINGS
-- Sesuaikan account_id dengan data di tabel accounts Anda
-- ================================================================

-- Cek dulu ID akun yang ada
-- SELECT id, code, name FROM accounts WHERE company_id = 1 ORDER BY code;

-- Insert settings (ganti [ID] dengan ID akun yang sesuai)
INSERT INTO `accounting_settings` (`company_id`, `setting_key`, `account_id`, `description`) VALUES
(1, 'account_receivable', NULL, 'Akun Piutang Usaha (1.1.03)'),
(1, 'revenue_bus', NULL, 'Pendapatan Jasa Bus (4.1.01)'),
(1, 'revenue_towing', NULL, 'Pendapatan Jasa Towing (4.1.02)'),
(1, 'revenue_hotel', NULL, 'Pendapatan Jasa Hotel (4.1.03)'),
(1, 'revenue_travel', NULL, 'Pendapatan Jasa Travel (4.1.04)'),
(1, 'revenue_rental', NULL, 'Pendapatan Sewa Kendaraan (4.1.05)'),
(1, 'default_cash', NULL, 'Akun Kas Default (1.1.01)'),
(1, 'default_bank', NULL, 'Akun Bank Default (1.1.02)')
ON DUPLICATE KEY UPDATE description = VALUES(description);

-- ================================================================
-- PART 7: UPDATE accounting_settings DENGAN ID AKUN YANG BENAR
-- Jalankan query ini setelah mengecek ID akun di tabel accounts
-- ================================================================

-- Update Piutang Usaha
UPDATE accounting_settings SET account_id = (
    SELECT id FROM accounts WHERE code = '1.1.03' AND company_id = 1 LIMIT 1
) WHERE company_id = 1 AND setting_key = 'account_receivable';

-- Update Pendapatan Bus
UPDATE accounting_settings SET account_id = (
    SELECT id FROM accounts WHERE code = '4.1.01' AND company_id = 1 LIMIT 1
) WHERE company_id = 1 AND setting_key = 'revenue_bus';

-- Update Pendapatan Towing
UPDATE accounting_settings SET account_id = (
    SELECT id FROM accounts WHERE code = '4.1.02' AND company_id = 1 LIMIT 1
) WHERE company_id = 1 AND setting_key = 'revenue_towing';

-- Update Pendapatan Hotel
UPDATE accounting_settings SET account_id = (
    SELECT id FROM accounts WHERE code = '4.1.03' AND company_id = 1 LIMIT 1
) WHERE company_id = 1 AND setting_key = 'revenue_hotel';

-- Update Pendapatan Travel
UPDATE accounting_settings SET account_id = (
    SELECT id FROM accounts WHERE code = '4.1.04' AND company_id = 1 LIMIT 1
) WHERE company_id = 1 AND setting_key = 'revenue_travel';

-- Update Pendapatan Rental
UPDATE accounting_settings SET account_id = (
    SELECT id FROM accounts WHERE code = '4.1.05' AND company_id = 1 LIMIT 1
) WHERE company_id = 1 AND setting_key = 'revenue_rental';

-- Update Default Kas
UPDATE accounting_settings SET account_id = (
    SELECT id FROM accounts WHERE code = '1.1.01' AND company_id = 1 LIMIT 1
) WHERE company_id = 1 AND setting_key = 'default_cash';

-- Update Default Bank
UPDATE accounting_settings SET account_id = (
    SELECT id FROM accounts WHERE code = '1.1.02' AND company_id = 1 LIMIT 1
) WHERE company_id = 1 AND setting_key = 'default_bank';

-- ================================================================
-- VERIFIKASI
-- ================================================================

-- Cek accounting_settings
SELECT * FROM accounting_settings WHERE company_id = 1;

-- Cek struktur journals
DESCRIBE journals;

-- Cek struktur order_payments
DESCRIBE order_payments;

-- Cek struktur transactions
DESCRIBE transactions;
