-- ================================================================
-- MIGRASI ORDER LAMA KE JURNAL AKUNTANSI
-- Travel Management System
-- ================================================================
-- 
-- PENTING: Jalankan SETELAH 01_setup_database.sql berhasil
-- dan accounting_settings sudah terisi dengan benar
--
-- ================================================================

-- ================================================================
-- STEP 1: CEK DATA YANG AKAN DIMIGRASI
-- ================================================================

-- Cek order yang belum punya jurnal invoice
SELECT 
    o.id,
    o.order_number,
    o.order_date,
    o.total_final_price,
    o.paid_amount,
    o.payment_status,
    o.status
FROM orders o
WHERE o.company_id = 1
AND o.total_final_price > 0
AND o.invoice_journal_id IS NULL
AND o.status NOT IN ('draft', 'cancelled')
ORDER BY o.order_date;

-- ================================================================
-- STEP 2: GENERATE JURNAL INVOICE UNTUK ORDER YANG SUDAH ADA
-- ================================================================

-- Dapatkan ID akun yang diperlukan
SET @company_id = 1;
SET @piutang_id = (SELECT account_id FROM accounting_settings WHERE company_id = @company_id AND setting_key = 'account_receivable');
SET @pendapatan_id = (SELECT account_id FROM accounting_settings WHERE company_id = @company_id AND setting_key = 'revenue_bus');

-- Cek apakah akun sudah terisi
SELECT @piutang_id as piutang_account, @pendapatan_id as pendapatan_account;

-- ================================================================
-- STEP 3: INSERT JURNAL UNTUK SETIAP ORDER (Manual per order)
-- ================================================================

-- Contoh untuk Order ID 29 (sesuaikan dengan order Anda)
-- Jalankan untuk setiap order yang perlu dimigrasi

-- Order 29: ORD/2601/0029 - Rp 7.910.000
INSERT INTO journals (company_id, order_id, journal_number, journal_type, journal_date, description, reference, status, posted_at, created_by)
SELECT 
    1, -- company_id
    29, -- order_id
    CONCAT('JU/2601/', LPAD((SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(journal_number, '/', -1) AS UNSIGNED)), 0) + 1 FROM journals WHERE company_id = 1 AND journal_number LIKE 'JU/2601/%'), 4, '0')),
    'order_invoice',
    '2026-01-12', -- order_date
    'Invoice Order: ORD/2601/0029 - Kepulangan Medan Kuala Namu',
    'ORD/2601/0029',
    'posted',
    NOW(),
    1
WHERE NOT EXISTS (SELECT 1 FROM journals WHERE order_id = 29 AND journal_type = 'order_invoice');

-- Insert journal details untuk order 29
INSERT INTO journal_details (journal_id, account_id, description, debit, credit)
SELECT 
    (SELECT id FROM journals WHERE order_id = 29 AND journal_type = 'order_invoice' LIMIT 1),
    @piutang_id,
    'Piutang dari ORD/2601/0029',
    7910000,
    0
WHERE EXISTS (SELECT 1 FROM journals WHERE order_id = 29 AND journal_type = 'order_invoice')
AND NOT EXISTS (SELECT 1 FROM journal_details WHERE journal_id = (SELECT id FROM journals WHERE order_id = 29 AND journal_type = 'order_invoice' LIMIT 1));

INSERT INTO journal_details (journal_id, account_id, description, debit, credit)
SELECT 
    (SELECT id FROM journals WHERE order_id = 29 AND journal_type = 'order_invoice' LIMIT 1),
    @pendapatan_id,
    'Pendapatan ORD/2601/0029',
    0,
    7910000
WHERE EXISTS (SELECT 1 FROM journals WHERE order_id = 29 AND journal_type = 'order_invoice');

-- Update order dengan journal_id
UPDATE orders SET invoice_journal_id = (
    SELECT id FROM journals WHERE order_id = 29 AND journal_type = 'order_invoice' LIMIT 1
) WHERE id = 29;

-- ================================================================
-- STEP 4: PROCEDURE UNTUK MIGRASI BATCH (Opsional - lebih advanced)
-- ================================================================

DELIMITER //

DROP PROCEDURE IF EXISTS MigrateOrderToJournal//

CREATE PROCEDURE MigrateOrderToJournal(IN p_order_id INT)
BEGIN
    DECLARE v_company_id INT;
    DECLARE v_order_number VARCHAR(50);
    DECLARE v_order_date DATE;
    DECLARE v_total DECIMAL(15,2);
    DECLARE v_event_name VARCHAR(255);
    DECLARE v_journal_id INT;
    DECLARE v_journal_number VARCHAR(50);
    DECLARE v_piutang_id INT;
    DECLARE v_pendapatan_id INT;
    DECLARE v_last_num INT;
    
    -- Get order data
    SELECT company_id, order_number, order_date, total_final_price, event_name
    INTO v_company_id, v_order_number, v_order_date, v_total, v_event_name
    FROM orders WHERE id = p_order_id;
    
    -- Get account IDs
    SELECT account_id INTO v_piutang_id 
    FROM accounting_settings 
    WHERE company_id = v_company_id AND setting_key = 'account_receivable';
    
    SELECT account_id INTO v_pendapatan_id 
    FROM accounting_settings 
    WHERE company_id = v_company_id AND setting_key = 'revenue_bus';
    
    -- Check if already has journal
    IF NOT EXISTS (SELECT 1 FROM journals WHERE order_id = p_order_id AND journal_type = 'order_invoice') THEN
        
        -- Generate journal number
        SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(journal_number, '/', -1) AS UNSIGNED)), 0) + 1
        INTO v_last_num
        FROM journals 
        WHERE company_id = v_company_id 
        AND journal_number LIKE CONCAT('JU/', DATE_FORMAT(v_order_date, '%y%m'), '/%');
        
        SET v_journal_number = CONCAT('JU/', DATE_FORMAT(v_order_date, '%y%m'), '/', LPAD(v_last_num, 4, '0'));
        
        -- Insert journal
        INSERT INTO journals (company_id, order_id, journal_number, journal_type, journal_date, description, reference, status, posted_at, created_by)
        VALUES (v_company_id, p_order_id, v_journal_number, 'order_invoice', v_order_date, 
                CONCAT('Invoice Order: ', v_order_number, ' - ', COALESCE(v_event_name, '')),
                v_order_number, 'posted', NOW(), 1);
        
        SET v_journal_id = LAST_INSERT_ID();
        
        -- Insert details - Debit Piutang
        INSERT INTO journal_details (journal_id, account_id, description, debit, credit)
        VALUES (v_journal_id, v_piutang_id, CONCAT('Piutang dari ', v_order_number), v_total, 0);
        
        -- Credit Pendapatan
        INSERT INTO journal_details (journal_id, account_id, description, debit, credit)
        VALUES (v_journal_id, v_pendapatan_id, CONCAT('Pendapatan ', v_order_number), 0, v_total);
        
        -- Update order
        UPDATE orders SET invoice_journal_id = v_journal_id WHERE id = p_order_id;
        
        SELECT CONCAT('Created journal ', v_journal_number, ' for order ', v_order_number) as result;
    ELSE
        SELECT CONCAT('Order ', v_order_number, ' already has journal') as result;
    END IF;
END//

DELIMITER ;

-- ================================================================
-- STEP 5: JALANKAN MIGRASI UNTUK SEMUA ORDER
-- ================================================================

-- Migrasi order 29
CALL MigrateOrderToJournal(29);

-- Migrasi order 30
CALL MigrateOrderToJournal(30);

-- Migrasi order 31
CALL MigrateOrderToJournal(31);

-- Atau migrasi batch dengan loop (untuk MySQL 8.0+)
-- Untuk MySQL versi lama, jalankan CALL satu per satu

-- ================================================================
-- STEP 6: VERIFIKASI HASIL MIGRASI
-- ================================================================

-- Cek jurnal yang sudah dibuat
SELECT 
    j.id,
    j.journal_number,
    j.journal_date,
    j.description,
    j.order_id,
    o.order_number,
    o.total_final_price
FROM journals j
LEFT JOIN orders o ON j.order_id = o.id
WHERE j.journal_type = 'order_invoice'
ORDER BY j.journal_date DESC;

-- Cek detail jurnal
SELECT 
    j.journal_number,
    a.code as account_code,
    a.name as account_name,
    jd.debit,
    jd.credit
FROM journal_details jd
JOIN journals j ON jd.journal_id = j.id
JOIN accounts a ON jd.account_id = a.id
WHERE j.journal_type = 'order_invoice'
ORDER BY j.journal_number, jd.id;

-- Cek total piutang
SELECT 
    SUM(CASE WHEN a.code = '1.1.03' THEN jd.debit - jd.credit ELSE 0 END) as total_piutang,
    SUM(CASE WHEN a.type = 'revenue' THEN jd.credit - jd.debit ELSE 0 END) as total_pendapatan
FROM journal_details jd
JOIN journals j ON jd.journal_id = j.id
JOIN accounts a ON jd.account_id = a.id
WHERE j.status = 'posted';

-- ================================================================
-- DONE!
-- ================================================================
